﻿Imports MetroFramework
Imports Microsoft.Win32
Imports VncSharp

Public Class VNCControl
    Public PC As String = ""
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Timer1.Enabled = True
        Catch ex As Exception
            '   MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try

            If (Rd.IsConnected) Then
                Rd.SendSpecialKeys(SpecialKeys.CtrlAltDel)
                trycrtlalt()
                Dim pc As String = ConnectComputer.ComboBox1.Text
                Dim th As New Threading.Thread(Sub() cmdDisableduac(pc))
                th.TrySetApartmentState(Threading.ApartmentState.STA)
                th.Start()
            End If
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Sub cmdDisableduac(ByVal pc As String)
        Try
            Dim info As New ProcessStartInfo()
            info.RedirectStandardOutput = True
            info.UseShellExecute = False
            info.CreateNoWindow = True
            info.WindowStyle = ProcessWindowStyle.Hidden
            info.FileName = "PsTools\psexec.exe"
            info.Arguments = "\\" & pc & " -s C:\Windows\System32\cmd.exe /k %windir%\System32\reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f"
            Dim p As Process = Process.Start(info)
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.RedirectStandardInput = True
            p.WaitForExit()
            p.Refresh()
            p.Close()
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Rd.Refresh()


    End Sub

    Public Sub trycrtlalt()
        Try
            'Dim environmentKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.CurrentUser, ConnectComputer.ComboBox1.Text).OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System")
            Dim key As RegistryKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, Me.Invoke(Function() ConnectComputer.ComboBox1.Text)).OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\", True)
            key.SetValue("SoftwareSASGeneration", 1, RegistryValueKind.DWord)
            key.Close()
        Catch ex As Exception
            ' MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            If (Rd.IsConnected) Then
                Rd.FillServerClipboard()
            End If
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub VncClientExampleForm_FormClosing() Handles Me.EnabledChanged
        ' If the user tries to close the window without doing a clean
        ' shutdown of the remote connection, do it for them.
        MsgBox("hey")
        Exit Sub
        Try
            Dim ComboboxesEventAddress As New EventHandler(AddressOf rd_Conncetionlost)
            RemoveHandler Rd.ConnectionLost, ComboboxesEventAddress
            If (Rd.IsConnected) Then
                Timer1.Enabled = False
                Rd.Disconnect()
            End If
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub


    Public Sub rd_ConnectComplete(ByVal sender As System.Object, ByVal e As VncSharp.ConnectEventArgs) Handles Rd.ConnectComplete
        ' Update the Form to match the geometry of remote desktop, including the height of the menu bar.
        Try
            ' Change the Form's title to match the remote desktop name
            Dim np As DotNetChromeTabs.ChromeTabControl.TabPage = Me.Parent
            If e.DesktopName IsNot Nothing Then
                np.Title = e.DesktopName
            End If
            ' Give the remote desktop focus now that it's connected.
            Rd.Focus()
            My.Settings.LastComputer = ConnectComputer.ComboBox1.Text
            My.Settings.Password = ConnectComputer.WTextBox1.Text
            My.Settings.Save()
        Catch ex As Exception
        End Try
    End Sub
    Public Sub rd_Conncetionlost(ByVal sender As System.Object, ByVal e As EventArgs) Handles Rd.ConnectionLost
        Try

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If Button1.BackColor = Color.Red Then
                Rd.SetInputMode(False)
                Button1.BackColor = Color.DodgerBlue
            Else
                Rd.SetInputMode(True)
                Button1.BackColor = Color.Red
            End If
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Public Sub startcmd(ByVal pc As String, ByVal parameter As String)
        Try
            Dim info As New ProcessStartInfo()
            info.RedirectStandardOutput = True
            info.UseShellExecute = False
            info.CreateNoWindow = True
            info.WindowStyle = ProcessWindowStyle.Hidden
            info.FileName = "PsTools\psexec.exe"
            info.Arguments = "\\" & pc & " -s -i   " & parameter
            Dim p As Process = Process.Start(info)
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.RedirectStandardInput = True
            p.WaitForExit()
            p.Refresh()
            p.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)
        Try

        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs)
        Try

        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Try
            Dim bitmap As Bitmap
            bitmap = New Bitmap(Rd.Width, Rd.Height)
            Rd.DrawToBitmap(bitmap, New Rectangle(0, 0, bitmap.Width, bitmap.Height))

            Dim image1 As Image = bitmap
            SaveFileDialog1.FileName = ExtractNumber(DateTime.Now)
            If SaveFileDialog1.ShowDialog <> Windows.Forms.DialogResult.Abort Then
                image1.Save(SaveFileDialog1.FileName & ".jpeg", Imaging.ImageFormat.Jpeg)
            End If
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Public Function ExtractNumber(original As String) As String
        Return New String(original.Where(Function(c) [Char].IsDigit(c)).ToArray())
    End Function


    Private Sub Button9_Click(sender As Object, e As EventArgs)
        Try


            Rd.SendSpecialKeys(VncSharp.SpecialKeys.WindowsPauseBreak)
            '  Rd.ManageKeyDownAndKeyUp(New KeyEventArgs(Keys.LWin), True)
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub MetroComboBox1_GiveFeedback(sender As Object, e As GiveFeedbackEventArgs) Handles MetroComboBox1.GiveFeedback

    End Sub

    Private Sub MetroComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MetroComboBox1.SelectedIndexChanged
        Try
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("CMD".ToLower) Then
                Dim pc As String = before(Rd.Hostname, "(")
                Dim th1 As New Threading.Thread(Sub() startcmd(pc, "CMD.exe"))
                th1.TrySetApartmentState(Threading.ApartmentState.STA)
                th1.Start()
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Bloquear".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.BlockWorkstation)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Tarefas".ToLowerInvariant) Then
                Dim pc As String = Before(Rd.Hostname, "(")
                Dim th1 As New Threading.Thread(Sub() startcmd(pc, "taskmgr.exe"))
                th1.TrySetApartmentState(Threading.ApartmentState.STA)
                th1.Start()
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Windows+d".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.WindowsD)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Windows+E".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.windowse)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Menu Executar".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.WindowsR)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Pause".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.WindowsPauseBreak)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("F4".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.AltF4)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Iniciar".ToLowerInvariant) Then
                Rd.SendSpecialKeys(VncSharp.SpecialKeys.CtrlEsc)
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Comando".ToLowerInvariant) Then
                Dim StatusDate As String
                StatusDate = InputBox("Qual comando você deseja usar no compuatdor remoto?", "Digite o comando", "")
                If StatusDate = "" Then
                    Exit Sub
                Else
                    Dim pc As String = Before(Rd.Hostname, "(")
                    Dim th1 As New Threading.Thread(Sub() startcmd(pc, StatusDate))
                    th1.TrySetApartmentState(Threading.ApartmentState.STA)
                    th1.Start()
                End If
            End If
            If MetroComboBox1.SelectedItem.ToString.ToLower.Contains("Arquivo".ToLowerInvariant) Then
                If OpenFileDialog1.ShowDialog <> DialogResult.Cancel Then
                    Dim pc As String = Before(Rd.Hostname, "(")
                    Dim fl As String = IO.Path.GetFileName(OpenFileDialog1.FileName)
                    IO.File.Copy(OpenFileDialog1.FileName, "\\" & pc & "\c$\" & fl, True)
                    Dim th1 As New Threading.Thread(Sub() startcmd(pc, "C:\" & fl))
                    th1.TrySetApartmentState(Threading.ApartmentState.STA)
                    th1.Start()
                End If
            End If
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try
            Me.Parent.Update()
            Me.Update()
            Rd.Update()
            Rd.Refresh()
            Rd.FullScreenUpdate()
        Catch ex As Exception

        End Try
    End Sub
    Function Before(value As String, a As String) As String
        ' Get index of argument and return substring up to that point.
        Dim posA As Integer = value.IndexOf(a)
        If posA = -1 Then
            Return ""
        End If
        Return value.Substring(0, posA)
    End Function


    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Try
            If Rd.IsConnected = False Then
                If My.Settings.Password <> "" Then
                    For Each x As Form In Application.OpenForms
                        Application.DoEvents()
                        Me.Refresh()
                        If x.Name.ToLower.Contains("Password".ToLower) Then
                            Dim x2 As PasswordDialog = x
                            Dim button2 As Button = x2.CancelButton
                            AddHandler button2.Click, AddressOf cancellingconnect
                            x2.Password = My.Settings.Password
                            x2.AcceptButton.PerformClick()
                            Timer2.Enabled = False
                            Exit Sub
                        End If
                    Next
                Else
                    For Each x As Form In Application.OpenForms
                        Application.DoEvents()
                        Me.Refresh()
                        If x.Name.ToLower.Contains("Password".ToLower) Then
                            Dim x2 As PasswordDialog = x
                            Dim button2 As Button = x2.CancelButton
                            AddHandler button2.Click, AddressOf cancellingconnect
                            Timer2.Enabled = False
                            Exit Sub
                        End If
                    Next
                End If
            End If
            Application.DoEvents()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub cancellingconnect()
        Try

            ConnectComputer.VNCtabs.TabPages.Remove(Me.Parent)
        Catch ex As Exception

        End Try
    End Sub

    Public Sub OnShown1(sender As Object, e As EventArgs) Handles Me.SizeChanged
        Try
            Timer2.Enabled = True

        Catch ex As Exception

        End Try
    End Sub

End Class
