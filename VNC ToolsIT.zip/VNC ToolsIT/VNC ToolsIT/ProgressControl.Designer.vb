﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProgressControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MetroProgressBar1 = New Wisder.W3Common.WMetroControl.Controls.MetroProgressBar()
        Me.Texto = New Wisder.W3Common.WMetroControl.Controls.MetroLabel()
        Me.SuspendLayout()
        '
        'MetroProgressBar1
        '
        Me.MetroProgressBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MetroProgressBar1.HideProgressText = False
        Me.MetroProgressBar1.Location = New System.Drawing.Point(0, 183)
        Me.MetroProgressBar1.Name = "MetroProgressBar1"
        Me.MetroProgressBar1.Size = New System.Drawing.Size(353, 23)
        Me.MetroProgressBar1.Step = 50
        Me.MetroProgressBar1.TabIndex = 0
        Me.MetroProgressBar1.Value = 50
        '
        'Texto
        '
        Me.Texto.AutoSize = True
        Me.Texto.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Texto.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Texto.FontSize = Wisder.W3Common.WMetroControl.MetroLabelSize.Tall
        Me.Texto.Location = New System.Drawing.Point(0, 158)
        Me.Texto.Name = "Texto"
        Me.Texto.Size = New System.Drawing.Size(286, 25)
        Me.Texto.TabIndex = 14
        Me.Texto.Text = "Tentando Conectar ao computador..."
        Me.Texto.UseCustomBackColor = True
        Me.Texto.UseCustomForeColor = True
        '
        'ProgressControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.Controls.Add(Me.Texto)
        Me.Controls.Add(Me.MetroProgressBar1)
        Me.Name = "ProgressControl"
        Me.Size = New System.Drawing.Size(353, 206)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MetroProgressBar1 As Wisder.W3Common.WMetroControl.Controls.MetroProgressBar
    Friend WithEvents Texto As Wisder.W3Common.WMetroControl.Controls.MetroLabel
End Class
