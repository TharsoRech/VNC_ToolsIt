﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VNCControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Rd = New VncSharp.RemoteDesktop()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MetroComboBox1 = New Wisder.W3Common.WMetroControl.Controls.MetroComboBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Rd
        '
        Me.Rd.AutoScroll = True
        Me.Rd.AutoScrollMinSize = New System.Drawing.Size(608, 427)
        Me.Rd.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Rd.Location = New System.Drawing.Point(0, 22)
        Me.Rd.Name = "Rd"
        Me.Rd.Size = New System.Drawing.Size(1002, 702)
        Me.Rd.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.MetroComboBox1)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1002, 22)
        Me.Panel1.TabIndex = 2
        '
        'MetroComboBox1
        '
        Me.MetroComboBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroComboBox1.DropDownWidth = 250
        Me.MetroComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.MetroComboBox1.ForeColor = System.Drawing.Color.Black
        Me.MetroComboBox1.FormattingEnabled = True
        Me.MetroComboBox1.IntegralHeight = False
        Me.MetroComboBox1.ItemHeight = 23
        Me.MetroComboBox1.Items.AddRange(New Object() {"CMD ", "Windows+E(Meu Computador)", "Windows+D(Mostrar Desktop)", "Abrir Gerenciador De Tarefas", "Windows+Pause Break(Propriedades Do Computador)", "Alt+F4(Fechar Janela)", "Bloquear Computador", "Menu Executar", "Abrir Menu Iniciar", "Executar Um Comando", "Executar Um arquivo"})
        Me.MetroComboBox1.Location = New System.Drawing.Point(519, 0)
        Me.MetroComboBox1.Name = "MetroComboBox1"
        Me.MetroComboBox1.PromptText = "Ação"
        Me.MetroComboBox1.Size = New System.Drawing.Size(483, 29)
        Me.MetroComboBox1.TabIndex = 0
        Me.MetroComboBox1.UseSelectable = True
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(427, 0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(92, 22)
        Me.Button4.TabIndex = 7
        Me.Button4.Text = "Atualizar"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button8.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(335, 0)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(92, 22)
        Me.Button8.TabIndex = 6
        Me.Button8.Text = "Salvar Print"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(232, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(103, 22)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Spy Mode"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(129, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(103, 22)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Colar Texto"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(0, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(129, 22)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Enviar Crtl Alt Del"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Timer2
        '
        '
        'VNCControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Rd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "VNCControl"
        Me.Size = New System.Drawing.Size(1002, 724)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Rd As VncSharp.RemoteDesktop
    Friend WithEvents Panel1 As Panel
    Friend WithEvents MetroComboBox1 As Wisder.W3Common.WMetroControl.Controls.MetroComboBox
    Friend WithEvents Button8 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents Button4 As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Timer2 As Timer
End Class
