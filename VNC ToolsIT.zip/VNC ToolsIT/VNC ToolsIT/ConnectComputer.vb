﻿Imports MetroFramework
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading

Public Class ConnectComputer

    Private Sub ConnectComputer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If My.Settings.LastComputer <> "." Then
                ComboBox1.Text = My.Settings.LastComputer
                My.Settings.Save()
            End If
            ComboBox2.Text = My.Settings.Mode
            If My.Settings.Password <> "." Then
                WTextBox1.Text = My.Settings.Password
                MetroCheckBox1.Checked = True
            End If

            MetroCheckBox1.Checked = My.Settings.Autenticar
            If My.Settings.Autenticar = False Then
                WTextBox1.Enabled = False
            Else
                WTextBox1.Enabled = True
            End If
            AddHandler MetroCheckBox1.CheckedChanged, AddressOf MetroCheckBox1_CheckedChanged
        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Sub getcomputers()
        Try
            Dim Domain As String
            Domain = Environment.UserDomainName

            Dim domainEntry As DirectoryServices.DirectoryEntry = New DirectoryServices.DirectoryEntry("WinNT://" + Domain)
            domainEntry.Children.SchemaFilter.Add("computer")
            For Each computer As DirectoryServices.DirectoryEntry In domainEntry.Children
                ComboBox1.Items.Add(computer.Name)
            Next
        Catch ex As Exception

        End Try
    End Sub

    <DllImport("user32.dll")> _
    Public Shared Function ToUnicode(virtualKeyCode As UInteger, scanCode As UInteger, keyboardState As Byte(), <Out, MarshalAs(UnmanagedType.LPWStr, SizeConst:=64)> receivingBuffer As StringBuilder, bufferSize As Integer, flags As UInteger) As Integer
    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim index As Integer = 0
        Try
            For Each x1 As DotNetChromeTabs.ChromeTabControl.TabPage In VNCtabs.TabPages
                If x1.Title.Contains(ComboBox1.Text) Then
                    VNCtabs.TabIndex = x1.TabIndex
                    Exit Sub
                End If
            Next
            Dim newtb As New DotNetChromeTabs.ChromeTabControl.TabPage
            newtb.CanClose = True
            newtb.SingleInstance = False
            newtb.Title = ComboBox1.Text
            Dim p As New ProgressControl
            p.Dock = DockStyle.Fill
            If ComboBox1.Text <> "" Then
                If ComboBox2.Text.Contains("Spy") Then
                    VNCtabs.TabPages.Add(newtb)
                    index = newtb.TabIndex
                    newtb.Controls.Add(p)
                    Application.DoEvents()
                    Dim newvnc As New VNCControl
                    newvnc.Dock = DockStyle.Fill
                    newvnc.PC = ComboBox1.Text
                    newvnc.Button1.BackColor = Color.Red
                    newvnc.Rd.Connect(ComboBox1.Text, True, True)
                    newtb.Controls.Remove(p)
                    newtb.Controls.Add(newvnc)

                Else
                    VNCtabs.TabPages.Add(newtb)
                    index = newtb.TabIndex
                    newtb.Controls.Add(p)
                    Application.DoEvents()
                    Dim newvnc As New VNCControl
                    newvnc.PC = ComboBox1.Text
                    newvnc.Dock = DockStyle.Fill
                    newvnc.Button1.BackColor = Color.WhiteSmoke
                    newvnc.Rd.Connect(ComboBox1.Text, True, True)
                    newtb.Controls.Remove(p)
                    newtb.Controls.Add(newvnc)
                End If

            End If


        Catch ex As Exception
            MetroMessageBox.Show(Me, ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Error)
            VNCtabs.TabPages.RemoveAt(Index)
        End Try
    End Sub




    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        My.Settings.Mode = ComboBox2.SelectedItem.ToString
        My.Settings.Save()
    End Sub

    Private Sub MetroCheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles MetroCheckBox2.CheckedChanged
        Try
            If MetroCheckBox2.CheckState = CheckState.Unchecked Then
                WTextBox1.UseSystemPasswordChar = True
            Else
                WTextBox1.UseSystemPasswordChar = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub MetroCheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles MetroCheckBox1.CheckedChanged
        Try
            If MetroCheckBox1.CheckState = CheckState.Checked Then
                My.Settings.Autenticar = True
                My.Settings.Save()
                WTextBox1.Enabled = True
                If WTextBox1.Text <> "" Then
                    My.Settings.Password = WTextBox1.Text
                    My.Settings.Save()
                End If
            Else
                My.Settings.Autenticar = False
                My.Settings.Save()
                WTextBox1.Enabled = False
            End If
        Catch ex As Exception

        End Try

    End Sub

    Protected Overrides Sub OnClosing(e As System.ComponentModel.CancelEventArgs)
        MyBase.OnClosing(e)
        Process.GetCurrentProcess.Kill()
    End Sub

    Private Sub MetroCheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles MetroCheckBox1.CheckedChanged
        Try
            My.Settings.Autenticar = True
            My.Settings.Save()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            My.Settings.Password = WTextBox1.Text
            My.Settings.Save()
        Catch ex As Exception

        End Try
    End Sub


End Class